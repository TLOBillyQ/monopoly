local items = {
  { id = 2001, name = "免费卡", tier = 1, shop_currency = "乐园币", shop_price = 100, weight = 500, angel_immune = false, timing = "post_action", usage = "确认使用，支付环节改为出示免费卡", description = "当你停留在其他玩家的地块上时，你可以选择使用免费卡，免交本次的租金。" },
  { id = 2002, name = "遥控骰子卡", tier = 1, shop_currency = "金币", shop_price = 5000, weight = 1000, angel_immune = false, timing = "pre_action", usage = "投骰子前点击骰子依次改变骰子上的点数，点击确认后投出这些点数", description = "在你行动前可以使用遥控骰子卡，可以遥控骰子投出的点数。" },
  { id = 2003, name = "骰子加倍卡", tier = 1, shop_currency = "金币", shop_price = 2500, weight = 1000, angel_immune = false, timing = "pre_move", usage = "确认使用，增加N个同点数的骰子，共同计算行动步数。", description = "在投出骰子后你可以使用加倍骰子卡，可以使当前投出的点数加倍。" },
  { id = 2004, name = "路障卡", tier = 1, shop_currency = "金币", shop_price = 5000, weight = 1000, angel_immune = true, timing = "manual", usage = "使用后视角拉高，可放置格子高亮闪烁，其他压暗，点击任意一格放下路障，恢复视角", description = "使用路障卡，在你前后3格内放置一个路障，任何玩家经过此地时强制停留。" },
  { id = 2005, name = "地雷卡", tier = 1, shop_currency = "金币", shop_price = 2500, weight = 1000, angel_immune = true, timing = "manual", usage = "使用后在脚下安装一个地雷", description = "使用地雷卡，在你脚下放置地雷，任何玩家经过此地时触发地雷，摧毁该玩家的座驾并让他强制住院。" },
  { id = 2006, name = "清障卡", tier = 1, shop_currency = "金币", shop_price = 2500, weight = 1000, angel_immune = false, timing = "pre_action", usage = "使用后放出一个机器人自动前进，清除12格以内路障地雷等障碍物。", description = "在你行动前可以使用清障卡，放出机器人清除前方障碍物。" },
  { id = 2007, name = "偷窃卡", tier = 2, shop_currency = "乐园币", shop_price = 100, weight = 500, angel_immune = true, timing = "pass_player", usage = "使用后压暗主场景，屏幕中间展示目标玩家道具栏，选择一个道具。", description = "当你路过其他玩家时，你可以选择使用偷窃卡，获得他的一个道具。" },
  { id = 2008, name = "怪兽卡", tier = 2, shop_currency = "乐园币", shop_price = 100, weight = 500, angel_immune = false, timing = "manual", usage = "使用后视角拉高，可拆除建筑高亮闪烁，其他压暗，点击任意一栋建筑释放怪兽，恢复视角", description = "使用怪兽卡，你可以选择前后3格内的其他玩家建筑，释放怪兽拆除该建筑。" },
  { id = 2009, name = "强征卡", tier = 2, shop_currency = "金豆", shop_price = 5, weight = 500, angel_immune = false, timing = "post_action", usage = "确认使用，支付环节改为支付给玩家地块+建筑总费用，改变地块所有权", description = "当你停留在其他玩家的地块上时，你可以选择使用强征卡，支付费用后你强制获得这块地块的所有权。" },
  { id = 2010, name = "免税卡", tier = 2, shop_currency = "金豆", shop_price = 5, weight = 300, angel_immune = false, timing = "tax_prompt", usage = "确认使用，支付环节改为出示免税卡", description = "当你需要支付税务时，你可以选择使用免税卡，抵扣本次税金。" },
  { id = 2011, name = "均富卡", tier = 2, shop_currency = "金豆", shop_price = 50, weight = 50, angel_immune = true, timing = "manual", usage = "使用后压暗主场景，屏幕中间展示其他玩家形象及其资金，下发显示自己资金，选择一个玩家确认后，滚动增减目标和自己的资金，恢复场景。", description = "使用均富卡，选择一个其他玩家，你和该玩家平分你们的总资金。" },
  { id = 2012, name = "流放卡", tier = 2, shop_currency = "金币", shop_price = 5000, weight = 1000, angel_immune = true, timing = "manual", usage = "使用后压暗主场景，屏幕中间展示其他玩家形象选择一个玩家确认后，恢复场景该玩家飞往深山中。", description = "使用流放卡，选择一个其他玩家，该玩家被强制流放到深山中。" },
  { id = 2013, name = "导弹卡", tier = 3, shop_currency = "金豆", shop_price = 5, weight = 500, angel_immune = false, timing = "manual", usage = "使用后视角拉高，可释放格子高亮闪烁，其他压暗，点击任意一格释放导弹，恢复视角", description = "使用导弹卡，你可以向前后3格范围内释放一枚导弹，摧毁该位置所有建筑、座驾，该位置玩家都住进医院。" },
  { id = 2014, name = "查税卡", tier = 3, shop_currency = "金豆", shop_price = 50, weight = 150, angel_immune = true, timing = "manual", usage = "使用后压暗主场景，屏幕中间展示其他玩家形象及其资金，选择一个玩家确认后，减少目标资金，恢复场景。", description = "使用查税卡，选择一个其他玩家，该玩家立即支付50%资金的所得税。" },
  { id = 2015, name = "请神卡", tier = 3, shop_currency = "金豆", shop_price = 20, weight = 200, angel_immune = false, timing = "manual", usage = "使用后压暗主场景，屏幕中间展示其他玩家形象及其附身神，选择一个玩家确认后，神仙飞到自己角色身上。", description = "使用请神卡，选择一个其他玩家，将附身于他的神仙请到自己身上。" },
  { id = 2016, name = "送神卡", tier = 3, shop_currency = "金豆", shop_price = 20, weight = 200, angel_immune = false, timing = "trigger_poor_god", usage = "确认后压暗主场景，屏幕中间展示其他玩家形象及其附身神，选择一个玩家确认后，自己角色身上的神仙飞到他的身上。", description = "使用送神卡，选择一个其他玩家，将附身自己的穷神送到他身上。" },
  { id = 2017, name = "财神卡", tier = 3, shop_currency = "金豆", shop_price = 10, weight = 200, angel_immune = false, timing = "manual", usage = "使用后财神飘在自身背后，5回合结束后财神消失", description = "使用财神卡，财神附身5回合，收到的租金和奖金翻倍。" },
  { id = 2018, name = "穷神卡", tier = 3, shop_currency = "金豆", shop_price = 10, weight = 200, angel_immune = false, timing = "manual", usage = "使用后压暗主场景，屏幕中间展示其他玩家形象选择一个玩家确认后，穷神飘在该玩家身后。", description = "使用穷神卡，选择一个其他玩家，令其穷神附身5回合，支付的租金和罚金翻倍。" },
  { id = 2019, name = "天使卡", tier = 3, shop_currency = "金豆", shop_price = 10, weight = 200, angel_immune = false, timing = "manual", usage = "使用后天使飘在自身背后，5回合结束后天使消失", description = "使用财神卡，天使附身5回合，免受负面卡牌效果影响。" },
}

return items
